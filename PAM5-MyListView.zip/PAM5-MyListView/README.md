# Pemrograman Aplikasi Mobile - MyListView

Tatak Goresta Putra Nanda - tatak.09@students.amikom.ac.id
Nim : 18.11.2442
Kelas : 18 IF-09

Project tentang ListView meliputi Simple, Custom dan RecyclerView
